import matplotlib.pyplot as plt
import numpy as np
import torch
from torch import nn
from torch.optim import Adam
from torch.utils.data import DataLoader, TensorDataset
import torch.nn.functional as F

from utils import load_dataset, problem


@problem.tag("hw4-A")
def F1(h: int) -> nn.Module:
    """Model F1, it should performs an operation W_d * W_e * x as written in spec.

    Note:
        - While bias is not mentioned explicitly in equations above, it should be used.
            It is used by default in nn.Linear which you can use in this problem.

    Args:
        h (int): Dimensionality of the encoding (the hidden layer).

    Returns:
        nn.Module: An initialized autoencoder model that matches spec with specific h.
    """

    return nn.Sequential(
        nn.Linear(784, h),
        nn.Linear(h, 784)
    )


@problem.tag("hw4-A")
def F2(h: int) -> nn.Module:
    """Model F1, it should performs an operation ReLU(W_d * ReLU(W_e * x)) as written in spec.

    Note:
        - While bias is not mentioned explicitly in equations above, it should be used.
            It is used by default in nn.Linear which you can use in this problem.

    Args:
        h (int): Dimensionality of the encoding (the hidden layer).

    Returns:
        nn.Module: An initialized autoencoder model that matches spec with specific h.
    """
    return nn.Sequential(
        nn.Linear(784, h),
        nn.ReLU(),
        nn.Linear(h, 784),
        nn.ReLU()
    )


@problem.tag("hw4-A")
def train(
    model: nn.Module, optimizer: Adam, train_loader: DataLoader, epochs: int = 40
) -> float:
    """
    Train a model until convergence on train set, and return a mean squared error loss on the last epoch.

    Args:
        model (Module): Model to train. Either F1, or F2 in this problem.
        optimizer (Adam): Optimizer that will adjust parameters of the model.
            Hint: You can try using learning rate of 5e-5.
        train_loader (DataLoader): DataLoader with training data.
            You can iterate over it like a list, and it will produce x
            where x is FloatTensor of shape (n, d).

    Note:
        - Unfortunately due to how DataLoader class is implemented in PyTorch
            "for x_batch in train_loader:" will not work. Use:
            "for (x_batch,) in train_loader:" instead.

    Returns:
        float: Final training error/loss
    """

    e = 0.0
    for i in range(epochs):
        for (x_batch,) in train_loader:
            optimizer.zero_grad()
            predictions = model(x_batch)
            if i == epochs -1:
                loss = nn.MSELoss()
                loss = loss(predictions, x_batch)
                loss.backward()
                e = loss.item()
            optimizer.step()
    return e


@problem.tag("hw4-A")
def evaluate(model: nn.Module, loader: DataLoader) -> float:
    """Evaluates a model on a provided dataset.
    It should return an average loss of that dataset.

    Args:
        model (Module): TRAINED Model to evaluate. Either F1, or F2 in this problem.
        loader (DataLoader): DataLoader with some data.
            You can iterate over it like a list, and it will produce x
            where x is FloatTensor of shape (n, d).

    Returns:
        float: Mean Squared Error on the provided dataset.
    """
    
    loss = nn.MSELoss()
    model.eval()
    test_loss = 0.0
    with torch.no_grad():
        for (x_batch,) in loader:
            x_batch_pred = model(x_batch)
            batch_loss = loss(x_batch_pred, x_batch)
            test_loss = test_loss + batch_loss.item()
        test_loss = test_loss / len(loader)
        return test_loss

@problem.tag("hw4-A", start_line=9)
def main():
    """
    Main function of autoencoders problem.

    It should:
        A. Train an F1 model with hs 32, 64, 128, report loss of the last epoch
            and visualize reconstructions of 10 images side-by-side with original images.
        B. Same as A, but with F2 model
        C. Use models from parts A and B with h=128, and report reconstruction error (MSE) on test set.

    Note:
        - For visualizing images feel free to use images_to_visualize variable.
            It is a FloatTensor of shape (10, 784).
        - For having multiple axes on a single plot you can use plt.subplots function
        - For visualizing an image you can use plt.imshow (or ax.imshow if ax is an axis)
    """
    (x_train, y_train), (x_test, _) = load_dataset("mnist")
    x = torch.from_numpy(x_train).float()
    x_test = torch.from_numpy(x_test).float()

    # Neat little line that gives you one image per digit for visualization in parts a and b
    images_to_visualize = x[[np.argwhere(y_train == i)[0][0] for i in range(10)]]


    train_loader = DataLoader(TensorDataset(x), batch_size=32, shuffle=True)
    test_loader = DataLoader(TensorDataset(x_test), batch_size=32, shuffle=True)

    run_for = "c"

    hs = [32, 64, 128]
    
    if run_for =="a":
        for h in hs:
            model = F1(h)
            optimizer = torch.optim.Adam(params=model.parameters(), lr=5*10**(-5))
            e = train(model, optimizer, train_loader, 40)
            
            fig, ax = plt.subplots(10, 2)
            for i in range(10):
                for j in range(2):
                    if j == 0:
                        ax.ravel()[i*2+j].imshow(images_to_visualize[i].reshape((28,28)))
                    else:
                        ax.ravel()[i*2+j].imshow(model(images_to_visualize[i]).detach().numpy().reshape(28, 28))
                    ax.ravel()[i*2+j].axes.xaxis.set_visible(False)
                    ax.ravel()[i*2+j].axes.yaxis.set_visible(False)
            fig.suptitle('F1 Reconstruction with h = ' + str(h))
            plt.show()

    if run_for =="b":
        for h in hs:
            model = F2(h)
            optimizer = torch.optim.Adam(params=model.parameters(), lr=5*10**(-5))
            e = train(model, optimizer, train_loader, 40)
            
            fig, ax = plt.subplots(10, 2)
            for i in range(10):
                for j in range(2):
                    if j == 0:
                        ax.ravel()[i*2+j].imshow(images_to_visualize[i].reshape((28,28)))
                    else:
                        ax.ravel()[i*2+j].imshow(model(images_to_visualize[i]).detach().numpy().reshape(28, 28))
                    ax.ravel()[i*2+j].axes.xaxis.set_visible(False)
                    ax.ravel()[i*2+j].axes.yaxis.set_visible(False)
            fig.suptitle('F1 Reconstruction with h = ' + str(h))
            plt.show()

    if run_for =="c":
        for m in [F1, F2]:
            model = m(128)
            optimizer = torch.optim.Adam(params=model.parameters(), lr=5*10**(-5))
            train(model, optimizer, train_loader, 40)
            val_test = evaluate(model, test_loader)
            print(val_test)



if __name__ == "__main__":
    main()
