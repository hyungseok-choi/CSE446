if __name__ == "__main__":
    from k_means import calculate_error, lloyd_algorithm  # type: ignore
else:
    from .k_means import lloyd_algorithm, calculate_error

import matplotlib.pyplot as plt
import numpy as np
import pickle
import time

from utils import load_dataset, problem


@problem.tag("hw4-A", start_line=1)
def main():
    """Main function of k-means problem

    You should:
        a. Run Lloyd's Algorithm for k=10, and report 10 centers returned.
        b. For ks: 2, 4, 8, 16, 32, 64 run Lloyd's Algorithm,
            and report objective function value on both training set and test set.
            (All one plot, 2 lines)

    NOTE: This code takes a while to run. For debugging purposes you might want to change:
        x_train to x_train[:10000]. CHANGE IT BACK before submission.
    """
    (x_train, _), (x_test, _) = load_dataset("mnist")

    run_for = "ct"
    
    if run_for == "b":
        centers, errors = lloyd_algorithm(x_train, 10)
        with open('A2b-centers.pickle','wb') as mysavedata:
            pickle.dump(centers, mysavedata)

        with open('A2b-errors.pickle','wb') as mysavedata:
            pickle.dump(errors, mysavedata)


    if run_for == "bt":
        with open('A2b-centers.pickle','rb') as myloaddata:
            centers = pickle.load(myloaddata)

        with open('A2b-errors.pickle','rb') as myloaddata:
            errors = pickle.load(myloaddata)

        fig, ax = plt.subplots(2, 5)
        for i in range(len(centers)):
            ax.ravel()[i].imshow(centers[i, :].reshape((28,28)), cmap='gray_r')
            ax.ravel()[i].axes.xaxis.set_visible(False)
            ax.ravel()[i].axes.yaxis.set_visible(False)
        fig.suptitle('MNIST K-mean visualization')
        plt.show()

    if run_for == "c":
        
        start = time.time()

        kList = [2, 4, 8, 16, 32, 64]

        train_error = []
        test_error = []

        for k in kList:
            centers, errors = lloyd_algorithm(x_train, k)
            with open('A2c-centers-' + str(k) + '.pickle','wb') as file:
                pickle.dump(centers, file)

            with open('A2c-trainerrors-' + str(k) + '.pickle','wb') as file:
                pickle.dump(errors, file)

            t_error = calculate_error(x_test, centers)

            with open('A2c-testerrors-' + str(k) + '.pickle', 'wb') as file:
                pickle.dump(t_error, file)
            
            train_error.append(errors[-1])
            test_error.append(t_error)

            print(k, errors[-1], t_error)
            print(time.time() - start)
            print()
        
        plt.plot(kList, train_error, "bo", label="Train errors")
        plt.plot(kList, test_error, "ro", label="Test errors")
        plt.xlabel("K")
        plt.ylabel("errors")
        plt.legend()
        plt.show()

    if run_for == "ct":

        kList = [2, 4, 8, 16, 32, 64]

        train_error = []
        test_error = []

        for k in kList:
            # centers, errors = lloyd_algorithm(x_train, k)
            # t_error = calculate_error(x_test, centers)

            with open('A2c-centers-' + str(k) + '.pickle','rb') as file:
                centers = pickle.load(file)

            with open('A2c-trainerrors-' + str(k) + '.pickle','rb') as file:
                errors = pickle.load(file)

            with open('A2c-testerrors-' + str(k) + '.pickle', 'rb') as file:
                t_error = pickle.load(file)
            
            train_error.append(errors[-1])
            test_error.append(t_error)

            print(errors[-1], t_error)
        
        plt.plot(kList, train_error, "b-", label="Train errors")
        plt.plot(kList, test_error, "r-", label="Test errors")
        plt.xlabel("K")
        plt.ylabel("errors")
        plt.legend()
        plt.show()



if __name__ == "__main__":
    main()
