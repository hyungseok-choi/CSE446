if __name__ == "__main__":
    from coordinate_descent_algo import train  # type: ignore
else:
    from .coordinate_descent_algo import train

from re import A
import matplotlib.pyplot as plt
import numpy as np

from utils import load_dataset, problem


@problem.tag("hw2-A", start_line=3)
def main():
    # df_train and df_test are pandas dataframes.
    # Make sure you split them into observations and targets

    # set run_for var among "c", "d", "e" and "f".
    run_for = "f"

    df_train, df_test = load_dataset("crime")

    train_y = df_train.iloc[:, 0].to_numpy()
    df_train = df_train.iloc[:,1:]

    columns = df_train.columns
    train_x = df_train.to_numpy()

    n, d = train_x.shape
    weight = np.zeros(d)

    y_mean = train_y.mean()
    l_max = np.max(np.abs((train_x.T@(train_y-y_mean))))*2

    lambda_ = []
    l = l_max

    if run_for == "c":
        non_zeros = []

    if run_for == "d":
        cols = ["agePct12t29", "pctWSocSec", "pctUrban", "agePct65up", "householdsize"]
        idx = [columns.get_loc(i) for i in cols]
        coefs = np.zeros((5,1))

    if run_for == "e":
        test_y = df_test.iloc[:, 0].to_numpy()
        test_x = df_test.iloc[:, 1:].to_numpy()
        mse = np.zeros((2,1))

    if run_for in ["c", "d", "e"]:
        while(l > 0.01):
            print(l)
            weight, b = train(train_x, train_y, l, 0.0001, weight)
            lambda_.append(l)

            # Plot nonzero weights (6-c)
            if run_for == "c":
                nz = np.count_nonzero(weight)
                non_zeros.append(nz)

            # Plot the regularization path (6-d)
            if run_for == "d":
                vals = np.asarray([weight[i] for i in idx]).reshape((-1,1))
                coefs = np.append(coefs, vals, 1)

            # Plot the squared error (6-e)
            if run_for == "e":
                B = b*np.ones(len(train_y))
                train_err = pow(np.linalg.norm(train_x@weight+B-train_y), 2)
                B = b*np.ones(len(test_y))
                test_err = pow(np.linalg.norm(test_x@weight+B-test_y), 2)
                val = np.asarray([train_err, test_err]).reshape((-1,1))
                mse = np.append(mse, val, 1)

            l /= 2

        # Plot the nonzero weights(6-c)
        if run_for == "c":
            plt.plot(lambda_, non_zeros, "-")
            plt.ylabel("Non-zero weights")
        
        # Plot the regularization path (6-d)
        if run_for == "d":
            plt.plot(lambda_, coefs[:,1:].T, "-")
            plt.legend(cols)
            plt.ylabel("Coefficient values")

        # Plot the squared error (6-e)
        if run_for == "e":
            plt.plot(lambda_, mse[:,1:].T, "-")
            plt.legend(["train_err", "test_err"])
            plt.ylabel("MSE")

        plt.xlabel("Lambda")
        plt.xscale('log')
        plt.show()
        return

    
    weight, b = train(train_x, train_y, 30, 0.0001)
    max_idx = np.argmax(weight)
    min_idx = np.argmin(weight)
    print(columns[max_idx], weight[max_idx], columns[min_idx], weight[min_idx])

if __name__ == "__main__":
    main()
